-------------- LOG ANALYZER ---------------


=== TABLE OF CONTENTS ===

1. Introduction
2. Requirements
3. Recommended modules
4. Installation & Configuration
5. How to run
6. Troubleshooting

--------------------------------------------

=== INTRODUCTION ===

--------------------------------------------

The Log analyzer application takes a .txt file as input containing log data of web 
servers and extracts, parses and stores data onto a relational database in a format 
that is used to easily filter out activities based on different parameters.  

The application is built with a friendly and interactive user interface to easily 
filter and access data based on user input and shows some important data in chart 
format.

For a full description of the project, refer to the documentation.

--------------------------------------------

=== REQUIREMENTS ===

--------------------------------------------

1. An IDE (Eclipse IDE for Java EE Developers)
2. JavaSE 11 (jdk 15.0.1) and above
3. MySQL 

--------------------------------------------

=== RECOMMENDED MODULES ===

--------------------------------------------

1. Java System Library [JavaSE-11]
2. JavaFX and jar files configured
3. mysql-connecter-java.jar file configured

--------------------------------------------

=== INSTALLATION & CONFIGURATION ===  

--------------------------------------------

1. Download e(fx)clipse 3.7.0 plugins from Eclipse MarketPlace
   Go to 'Help' -> 'Eclipse Marketplace' -> search for 'e(fx)clipse' -> install
   Then download the JavaFx SDK from 'https://gluonhq.com/products/javafx/'  
   and set the .jar file in modulepath.

2. Download MySQl latest version and install it 
   visit : 'dev.mySql.com/downloads'

3. Download 'Connector/J 8.0.25' from 'https://dev.mysql.com/downloads/connector/j/'
   Click on 'JRE System Library' of your project -> 'Build Path' -> 'Configure Build Path' -> 'Add External JARs' -> Select the jar file from the downloaded file -> 'Apply and Close'

4. Set up the required database and table.
   Create a table with the following SQL Query:
   create table log (ID int NOT NULL, date varchar(20), time varchar(20), ipAddress varchar(100), userAgent varchar(255), statusCode varchar(20), 
                     requestType varchar(20), api varchar(100), userLogin varchar(100), userName varchar(100), enterpriseId varchar(100), 
                     enterpriseName varchar(255));

--------------------------------------------

=== HOW TO RUN === 

--------------------------------------------

Step 1 - Set the file path into the code.
Step 2 - Run Log_analyzer.java.
Step 3 - Run Main.java

--------------------------------------------

=== TROUBLESHOOTING === 

--------------------------------------------

If there is problem in connection to database, host the SQLserver on 'localhost:3306/'
configure the username and password and change the configuration in the code.

--------------------------------------------
