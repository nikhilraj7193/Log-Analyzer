package application;
import java.io.*;
import java.sql.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Scanner;
import java.util.regex.*;

// Model to save the data extracted of log
class Data {
	String date;
	String time;
	String ipAddress;
	String userAgent;
	String statusCode;
	String requestType;
	String api;
	String userLogin;
	String userName;
	String enterpriseId;
	String enterpriseName;
	
}

public class Log_analyzer {
	
	public static Connection connection;
	
	public static void main(String[] args) throws SQLException {   
		
		try {   // database connection
			Class.forName("com.mysql.cj.jdbc.Driver");
			String dburl = "jdbc:mysql://localhost:3306/logdatabase";
			String username = "root";
			String pass = "";
			connection = DriverManager.getConnection(dburl, username, pass);
			
		}catch(Exception e){
			throw new RuntimeException("Error");
		}
		
		
		try {
			
			File file = new File("C:\\\\Users\\\\rockr\\\\eclipse-workspace\\\\Log_Analyzer_UI\\\\src\\\\application\\\\logs.txt"); // log file input path
			Scanner br = new Scanner(file);
			
			
			String text = "";
			String dateRegEx="(\\d{4}([.\\-/])\\d{1,2}([.\\-/])\\d{1,4})";
			Pattern patternDate = Pattern.compile(dateRegEx);
			int i = 0;
			int j = 0;
			
			Log_extractor extractor = new Log_extractor();  
			while(br.hasNextLine()) {
				
				String lines = br.nextLine();
				
				// concatenating the text till we get date pattern
				Matcher matcherDate = patternDate.matcher(lines);
				if(matcherDate.find()) {
					if(i!=0) {
						extractor.extractData(j,text); // passing a complete log to Log-extractor class
						j++;
					}
					i = 1;
		            text = lines;
		        }else {
		        	text = text + lines;
		        }
				
			}
			
			// for the last log
			extractor.extractData(j,text);
			j++;
			br.close();
			
		} catch (FileNotFoundException e) {
			System.out.println("Error occured");
			e.printStackTrace();
		}
		
		
		// Getting data from database
		String sql = "select * from logdata";
		
		Statement statement = connection.createStatement();
		ResultSet result = statement.executeQuery(sql);
		
		while(result.next()) {
			System.out.println(result.getLong("ID"));
			System.out.println(result.getString("date"));
			System.out.println(result.getString("time"));
			System.out.println(result.getString("ipAddress"));
			System.out.println(result.getString("userAgent"));
			System.out.println(result.getString("statusCode"));
			System.out.println(result.getString("requestType"));
			System.out.println(result.getString("api"));
			System.out.println(result.getString("userLogin"));
			System.out.println(result.getString("userName"));
			System.out.println(result.getString("enterpriseId"));
			System.out.println(result.getString("enterpriseName"));
			System.out.println("---------------------------");
		}
	
		
		
             

	}

}
