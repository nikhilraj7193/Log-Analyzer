package application;
import javafx.beans.property.SimpleStringProperty;

// Class to save data into Table_View
public class Table_Data {
	
    private SimpleStringProperty date;
    private SimpleStringProperty time;
    private SimpleStringProperty ipAddress;
	private SimpleStringProperty userAgent;
	private SimpleStringProperty statusCode;
	private SimpleStringProperty requestType;
	private SimpleStringProperty api;
	private SimpleStringProperty userLogin;
	private SimpleStringProperty userName;
	private SimpleStringProperty enterpriseId;
	private SimpleStringProperty enterpriseName;
	
	// Constructor
	Table_Data(String date, String time, String ipAddress, String userAgent, String statusCode, String requestType, String api, String userLogin, String userName, String enterpriseId, String enterpriseName) {
		this.date = new SimpleStringProperty(date);
		this.time = new SimpleStringProperty(time);
		this.ipAddress = new SimpleStringProperty(ipAddress);
		this.userAgent = new SimpleStringProperty(userAgent);
		this.statusCode = new SimpleStringProperty(statusCode);
		this.requestType = new SimpleStringProperty(requestType);
		this.api = new SimpleStringProperty(api);
		this.userLogin = new SimpleStringProperty(userLogin);
		this.userName = new SimpleStringProperty(userName);
		this.enterpriseId = new SimpleStringProperty(enterpriseId);
		this.enterpriseName = new SimpleStringProperty(enterpriseName);
	}
	
	
	// Getter methods
	public String getDate() {
        return date.get();
    }
    
    public String getTime() {
        return time.get();
    }
    
    public String getIpAddress() {
        return ipAddress.get();
    }
    
    public String getUserAgent() {
        return userAgent.get();
    }
    
    public String getStatusCode() {
        return statusCode.get();
    }
    
    public String getRequestType() {
        return requestType.get();
    }
    
    public String getApi() {
        return api.get();
    }
    
    public String getUserLogin() {
        return userLogin.get();
    }
    
    public String getUserName() {
        return userName.get();
    }
    
    public String getEnterpriseId() {
        return enterpriseId.get();
    }
    
    public String getEnterpriseName() {
        return enterpriseName.get();
    }
    

	
}
