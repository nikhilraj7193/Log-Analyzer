package application;
import java.sql.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.DriverManager;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Log_extractor {
	
	public static Connection connection;
	
	public Data extractData(int j, String line) throws SQLException {
		
		Data data = new Data(); // new data object
		
		try { // database connection
			Class.forName("com.mysql.cj.jdbc.Driver");
			String dburl = "jdbc:mysql://localhost:3306/logdatabase";
			String username = "root";
			String pass = "";
			connection = DriverManager.getConnection(dburl, username, pass);
		}catch(Exception e){
			throw new RuntimeException("Error");
		}
		
		
		// Extracting data using regular expression
		String dateRegEx="(\\d{4}([.\\-/])\\d{1,2}([.\\-/])\\d{1,4})";
		Pattern patternDate = Pattern.compile(dateRegEx);
		Matcher matcherDate = patternDate.matcher(line);
        if(matcherDate.find()) {
            data.date = matcherDate.group(0);
        }else {
        	data.date = "N/A";
        }
        
        // Extracting time using regular expression
        String timeRegEx="(?:2[0-3]|[01]?[0-9]):[0-5][0-9]:[0-5][0-9]";
		Pattern patternTime = Pattern.compile(timeRegEx);
		Matcher matcherTime = patternTime.matcher(line);
        if(matcherTime.find()) {
            data.time = matcherTime.group(0);
        }else {
        	data.time = "N/A";
        }
        
        
        int num;
        String x;
        int hash_index;
        
        // Extracting IP Address using index and substring
        if(line.contains("IP-Address")) {
			num = line.indexOf("IP-Address");
			x = line.substring(num);
			hash_index = x.indexOf("#");
			data.ipAddress = x.substring("IP-Address=".length(),hash_index);
		}
		else {
			data.ipAddress = "N/A";
		}
        
        // Extracting User Agent using index and substring
        if(line.contains("User-Agent")) {
			num = line.indexOf("User-Agent");
			x = line.substring(num);
			hash_index = x.indexOf("#");
			data.userAgent = x.substring("User-Agent=".length(),hash_index);
		}
		else {
			data.userAgent = "N/A";
		}
        
        // Extracting Status code using index and substring
        if(line.contains("Status-Code")) {
			num = line.indexOf("Status-Code");
			x = line.substring(num);
			hash_index = x.indexOf("#");
			data.statusCode = x.substring("Status-Code=".length(),hash_index);
		}
		else {
			data.statusCode = "N/A";
		}
        
        // Extracting Request Type using index and substring
        if(line.contains("Request-Type")) {
			num = line.indexOf("Request-Type");
			x = line.substring(num);
			hash_index = x.indexOf("#");
			data.requestType = x.substring("Request-Type=".length(),hash_index);
		}
		else {
			data.requestType = "N/A";
		}
        
        // Extracting API using index and substring
        if(line.contains("API")) {
			num = line.indexOf("API");
			x = line.substring(num);
			hash_index = x.indexOf("#");
			data.api = x.substring("API=".length(),hash_index);
		}
		else {
			data.api = "N/A";
		}
        
        // Extracting User Login using index and substring
        if(line.contains("User-Login")) {
			num = line.indexOf("User-Login");
			x = line.substring(num);
			hash_index = x.indexOf("#");
			data.userLogin = x.substring("User-Login=".length(),hash_index);
		}
		else {
			data.userLogin = "N/A";
		}
        
        // Extracting User Name using index and substring
        if(line.contains("User-Name")) {
			num = line.indexOf("User-Name");
			x = line.substring(num);
			hash_index = x.indexOf("#");
			data.userName = x.substring("User-Name=".length(),hash_index);
		}
		else {
			data.userName = "N/A";
		}
        
        // Extracting Enterprise ID using index and substring
        if(line.contains("EnterpriseId")) {
			num = line.indexOf("EnterpriseId");
			x = line.substring(num);
			hash_index = x.indexOf("#");
			data.enterpriseId = x.substring("EnterpriseId=".length(),hash_index);
		}
		else {
			data.enterpriseId = "N/A";
		}
        
        // Extracting Enterprise Name using index and substring
        if(line.contains("EnterpriseName")) {
			num = line.indexOf("EnterpriseName");
			x = line.substring(num);
			hash_index = x.indexOf("#");
			data.enterpriseName = x.substring("EnterpriseName=".length(),hash_index);
		}
		else {
			data.enterpriseName = "N/A";
		}
    	
        
        // Inserting extracted log data into the database 
        String sql = "insert into logdata(ID, date, time, ipAddress, userAgent, statusCode, requestType, api, userLogin, userName, enterpriseID, enterpriseName) values (?,?,?,?,?,?,?,?,?,?,?,?)";
        PreparedStatement preparedStatement = connection.prepareStatement(sql);
        preparedStatement.setLong(1, j);
		preparedStatement.setString(2, data.date);
		preparedStatement.setString(3, data.time);
		preparedStatement.setString(4, data.ipAddress);
		preparedStatement.setString(5, data.userAgent);
		preparedStatement.setString(6, data.statusCode);
		preparedStatement.setString(7, data.requestType);
		preparedStatement.setString(8, data.api);
		preparedStatement.setString(9, data.userLogin);
		preparedStatement.setString(10, data.userName);
		preparedStatement.setString(11, data.enterpriseId);
		preparedStatement.setString(12, data.enterpriseName);
		preparedStatement.executeUpdate();
        return data;
        
        
	}
}
