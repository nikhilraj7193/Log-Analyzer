package application;

import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ResourceBundle;


import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.layout.AnchorPane;

import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.chart.CategoryAxis;
import javafx.scene.chart.LineChart;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.PieChart;
import javafx.scene.chart.XYChart;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.TableColumn;

public class MainController implements Initializable {
	
	// Id's of all the elements on GUI
	@FXML
	private AnchorPane main_pain;
	@FXML
	private TableView<Table_Data> log_table;
	@FXML
	private TableColumn<Table_Data, String> log_date;
	@FXML
	private TableColumn<Table_Data, String> log_time;
	@FXML
	private TableColumn<Table_Data, String> log_IP;
	@FXML
	private TableColumn<Table_Data, String> log_user_agent;
	@FXML
	private TableColumn<Table_Data, String> log_status_code;
	@FXML
	private TableColumn<Table_Data, String> log_request_type;
	@FXML
	private TableColumn<Table_Data, String> log_api;
	@FXML
	private TableColumn<Table_Data, String> log_user;
	@FXML
    private TableColumn<Table_Data, String> log_user_id;
	@FXML
	private TableColumn<Table_Data, String> log_enterprise_id;
	@FXML
	private TableColumn<Table_Data, String> log_enterprise_name;
	@FXML
    private PieChart status_code_pichart;
	@FXML
    private PieChart request_pi_chart;
	@FXML
    private ChoiceBox<String> choiceBox;
	@FXML
    private TextField SearchTextField;
    @FXML
    private Button searchButton;
    @FXML
    private Button refresh;
    @FXML
    private LineChart<String, Integer> lineChart;
    @FXML
    private CategoryAxis x;
    @FXML
    private NumberAxis y;

   
    static Connection connection;
	ObservableList<Table_Data> tableData = FXCollections.observableArrayList();
	@SuppressWarnings("unchecked")
	public void initialize(URL url, ResourceBundle rb) {
		
		
	    try { // database connection
			Class.forName("com.mysql.cj.jdbc.Driver");
			String dburl = "jdbc:mysql://localhost:3306/logdatabase";
			String username = "root";
			String pass = "";
			connection = DriverManager.getConnection(dburl, username, pass);
			
			String sql = "select * from logdata";
			
			Statement statement = connection.createStatement();
			ResultSet result = statement.executeQuery(sql);
			
			while(result.next()) {  // adding the retrieved data into the TableView
				tableData.add(new Table_Data(result.getString("date"), 
											result.getString("time"), 
											result.getString("ipAddress"), 
											result.getString("userAgent"), 
											result.getString("statusCode"), 
											result.getString("requestType"), 
											result.getString("api"), 
											result.getString("userLogin"), 
											result.getString("userName"), 
											result.getString("enterpriseId"), 
											result.getString("enterpriseName")
											));
				}
			
		}catch(Exception e){
			throw new RuntimeException("Error");
		}
	    
	    
		
		// Setting the cells of Table_View with the property defined in Table_Data class
		log_date.setCellValueFactory(new PropertyValueFactory<Table_Data,String>("date"));
		log_time.setCellValueFactory(new PropertyValueFactory<Table_Data,String>("time"));
		log_IP.setCellValueFactory(new PropertyValueFactory<Table_Data,String>("ipAddress"));
		log_user_agent.setCellValueFactory(new PropertyValueFactory<Table_Data,String>("userAgent"));
		log_status_code.setCellValueFactory(new PropertyValueFactory<Table_Data,String>("statusCode"));
		log_request_type.setCellValueFactory(new PropertyValueFactory<Table_Data,String>("requestType"));
		log_api.setCellValueFactory(new PropertyValueFactory<Table_Data,String>("api"));
		log_user.setCellValueFactory(new PropertyValueFactory<Table_Data,String>("userName"));
		log_user_id.setCellValueFactory(new PropertyValueFactory<Table_Data,String>("userLogin"));
		log_enterprise_id.setCellValueFactory(new PropertyValueFactory<Table_Data,String>("enterpriseId"));
		log_enterprise_name.setCellValueFactory(new PropertyValueFactory<Table_Data,String>("enterpriseName"));
		
		
		// Setting Items into TableView
		log_table.setItems(tableData);
		
		
		// Creating a choice Box
		choiceBox.getItems().addAll("Date", "Status Code", "Request Type", "API", "User ID", "User Name", "Enterprise Id", "Enterprise Name");
		choiceBox.setValue("Select Property");
		
		
		// Retrieving statusCode and its count to display in pie Chart
		String statusCodequery = "SELECT statusCode, count(statusCode) as countOfStatus from logdata group by statusCode";
		try {
			
			// Adding Data into pie chart
			ObservableList<PieChart.Data> statusCodePieChartData = FXCollections.observableArrayList();
			Statement statement = connection.createStatement();
			ResultSet result = statement.executeQuery(statusCodequery);
			
			while(result.next()) {
				statusCodePieChartData.add(new PieChart.Data(result.getString("statusCode"), result.getInt("countOfStatus")));
			}
			
			request_pi_chart.setData(statusCodePieChartData);
			request_pi_chart.setTitle("Status code Information");
		
		}catch(Exception e){
			System.out.print(e);
		}
		
		
		// Retrieving requestType and its count to display in pie Chart
		String requestTypequery = "SELECT requestType, count(requestType) as countOfRequestType from logdata group by requestType";
		try {
			
			// Adding Data into pie chart
			ObservableList<PieChart.Data> apiPieChartData = FXCollections.observableArrayList();
			Statement statement = connection.createStatement();
			ResultSet result = statement.executeQuery(requestTypequery);
			
			while(result.next()) {
				apiPieChartData.add(new PieChart.Data(result.getString("requestType"), result.getInt("countOfRequestType")));
			}
			
			status_code_pichart.setData(apiPieChartData);
			status_code_pichart.setTitle("Request Type Information");
		
		}catch(Exception e){
			System.out.print(e);
		}
		
		
		// Retrieving date and its count to display in line chart
		String logsOnQuery = "select date, count(date) as logsOn from logdata group by date";
		try {
			
			// Displaying data into line chart
			XYChart.Series<String, Integer> series = new XYChart.Series<String, Integer>();
		    Statement statement = connection.createStatement();
			ResultSet result = statement.executeQuery(logsOnQuery);
			
			while(result.next()) {
				series.getData().add(new XYChart.Data<String, Integer>(result.getString("date"),result.getInt("logsOn")));
			}
			
			lineChart.getData().addAll(series);
			
			
			
		}catch(Exception e){
			System.out.print(e);
		}
			
		
	}
	
	
	// Action on pressing search button
	@FXML
    public void filterLogs(ActionEvent event) {
		
		
		// Getting textFied and choice box inputs from GUI
		String searchText = SearchTextField.getText();
		String choiceBoxText = choiceBox.getValue();
		
		
		if(!choiceBoxText.equals("Select Property") && choiceBoxText != null) {
			
			String query = "";
			// Executing the query based on inputs 
			switch (choiceBoxText) //Switch on choiceBox value
	        {
		        case "Date":
		        	query = "select * from logdata where date = '" + searchText + "';";
		            break;
		        case "Request Type":
		        	query = "select * from logdata where requestType = '" + searchText + "';";
		        	break;    
		        case "User Name":
		        	query = "select * from logdata where userName like '%" + searchText + "%';";
		        	break;
		        case "Status Code":
		        	query = "select * from logdata where statusCode = '" + searchText + "';";
		        	break;
		        case "API":
		        	query = "select * from logdata where api like '%" + searchText + "%';";
		        	break;
		        case "User ID":
		        	query = "select * from logdata where userLogin like '%" + searchText + "%';";
		        	break;
		        case "Enterprise Id":
		        	query = "select * from logdata where enterpriseId = '" + searchText + "';";
		        	break;
		        case "Enterprise Name":
		        	query = "select * from logdata where enterpriseName like '%" + searchText + "%';";
		        	break;	
	            
	        } 
			
			// Setting the TableView with new filtered data
			ObservableList<Table_Data> temptableData = FXCollections.observableArrayList();
			try {
				
				Statement statement = connection.createStatement();
				ResultSet result = statement.executeQuery(query);
				
				while(result.next()) {
					temptableData.add(new Table_Data(result.getString("date"), 
												result.getString("time"), 
												result.getString("ipAddress"), 
												result.getString("userAgent"), 
												result.getString("statusCode"), 
												result.getString("requestType"), 
												result.getString("api"), 
												result.getString("userLogin"), 
												result.getString("userName"), 
												result.getString("enterpriseId"), 
												result.getString("enterpriseName")
												));
					}
			
			}catch(Exception e){
				System.out.print(e);
				log_table.setItems(tableData);
			}
			
			
			log_table.setItems(temptableData);	
			
		}else if(choiceBoxText == null) {
			SearchTextField.setText(" ");
			log_table.setItems(tableData);
		}
			
	}
	
	
	
	// Action on pressing Refresh button
	@FXML
    void onRefresh(ActionEvent event) {
		
		// Setting tableView with original data
		log_table.setItems(tableData);
		SearchTextField.setText(" ");
    }
	
	
	
	

}
